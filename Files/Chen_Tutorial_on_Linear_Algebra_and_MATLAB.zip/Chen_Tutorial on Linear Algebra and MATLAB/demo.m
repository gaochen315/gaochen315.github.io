clear all

% Read image
img_name = 'HICO_test2015_00000024.jpg';
img      = imread(img_name);
figure()
imshow(img)

% image manipulation 
img_gray     = rgb2gray(img);
figure()
imshow(img_gray)

img_reversed = img(:,end:-1:1,:);
figure()
imshow(img_reversed)

% Draw bounding box
H_box    = [30, 40, 300, 600];
O_box    = [120,45, 180, 250];
img_anno = DrawBox(img, H_box,O_box);
figure()
imshow(img_anno)

% Crop image
Cropped_H = img(H_box(2):H_box(4), H_box(1):H_box(3), :);
figure()
imshow(Cropped_H)

% Save image
imwrite(Cropped_H, 'Cropped_H.png');