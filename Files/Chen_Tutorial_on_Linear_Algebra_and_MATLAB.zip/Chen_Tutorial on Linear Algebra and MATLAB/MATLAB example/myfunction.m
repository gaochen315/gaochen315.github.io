function y = myfunction(x)
% Function of one argument with one return value

a = [-2 -1 0 1];              % Have a global variable of the same name
y = a + x;
