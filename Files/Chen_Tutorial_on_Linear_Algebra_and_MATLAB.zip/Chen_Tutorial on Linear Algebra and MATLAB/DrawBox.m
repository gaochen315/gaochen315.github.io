function img = DrawBox(img, H,O)

img(H(2):H(4),max(1, H(1)-2) : min(H(1)+2, size(img, 2)),:) = repmat(reshape([255 0 0],[1,1,3]),H(4)-H(2)+1,min(H(1)+2, size(img, 2)) - max(1, H(1)-2) + 1, 1);
img(H(2):H(4),max(1, H(3)-2) : min(H(3)+2, size(img, 2)),:) = repmat(reshape([255 0 0],[1,1,3]),H(4)-H(2)+1,min(H(3)+2, size(img, 2)) - max(1, H(3)-2) + 1, 1);
img(max(1, H(2)-2) : min(H(2)+2, size(img, 1)) ,H(1):H(3),:) = repmat(reshape([255 0 0],[1,1,3]),min(H(2)+2, size(img, 1)) - max(1, H(2)-2) + 1, H(3)-H(1)+1,1);
img(max(1, H(4)-2) : min(H(4)+2, size(img, 1)) ,H(1):H(3),:) = repmat(reshape([255 0 0],[1,1,3]),min(H(4)+2, size(img, 1)) - max(1, H(4)-2) + 1, H(3)-H(1)+1,1);

img(O(2):O(4),max(1, O(1)-2) : min(O(1)+2, size(img, 2)),:) = repmat(reshape([0 0 255],[1,1,3]),O(4)-O(2)+1,min(O(1)+2, size(img, 2)) - max(1, O(1)-2) + 1, 1);
img(O(2):O(4),max(1, O(3)-2) : min(O(3)+2, size(img, 2)),:) = repmat(reshape([0 0 255],[1,1,3]),O(4)-O(2)+1,min(O(3)+2, size(img, 2)) - max(1, O(3)-2) + 1, 1);
img(max(1, O(2)-2) : min(O(2)+2, size(img, 1)) ,O(1):O(3),:) = repmat(reshape([0 0 255],[1,1,3]),min(O(2)+2, size(img, 1)) - max(1, O(2)-2) + 1, O(3)-O(1)+1,1);
img(max(1, O(4)-2) : min(O(4)+2, size(img, 1)) ,O(1):O(3),:) = repmat(reshape([0 0 255],[1,1,3]),min(O(4)+2, size(img, 1)) - max(1, O(4)-2) + 1, O(3)-O(1)+1,1);

end